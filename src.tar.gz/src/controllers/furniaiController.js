/**
 * FurnIAI — Controller
 * REST 接口控制器，所有 /api/ai/furniai 路由的处理函数
 */
const FurniaiTask = require('../models/FurniaiTask')
const geminiClient = require('../services/geminiClient')
const promptBuilder = require('../services/promptBuilder')
const imageProcessor = require('../services/imageProcessor')
const taskQueue = require('../services/taskQueue')
const configManager = require('../services/configManager')
const jwtCounter = require('../utils/jwtCounter')
const { successResponse, errorResponse, paginatedResponse } = require('../utils/response')
const crypto = require('crypto')

/**
 * 将 auto 通道解析为当前配置中实际会使用的通道 ID（仅用于提交时预填充）
 * auto 模式按 channelMode 或 channelPriority 中第一个启用通道的 ID 来确定
 * 注意：批量任务的真正通道由 taskQueue 在生图成功后从 result.channel 回写
 */
function resolveAutoChannelId(channelId) {
  if (channelId && channelId !== 'auto') return channelId
  const config = configManager.get()
  // 如果 channelMode 不是 auto，直接用 channelMode 值作为通道 ID
  const mode = config?.channelMode || 'auto'
  if (mode !== 'auto') return mode
  // auto 模式：取 channelPriority 中第一个启用的通道 ID
  const channels = config?.channelPriority || []
  const first = channels.find(c => c.enabled)
  return first?.id || 'auto'
}

// 异步创建单次调用的任务记录（不阻塞响应）
// channel: 实际使用的通道 ID（由 generateImage 返回），不传则走 resolveAutoChannelId 兜底
// model: 实际使用的模型名称（由 generateImage 返回）
// imageDataUrl: 成功时传入 data:image/png;base64,xxx 格式的图片，异步存入 GridFS
// extra: { prompt, referenceImages, userContext } 额外输入参数（确保管理面板能看到所有输入）
// extra.referenceImages 中的图片会异步存入 GridFS，存 fileId 而非原始 base64
function logSingleCallTask(userId, taskType, status, startTime, channel, model, imageDataUrl, extra = {}) {
  const now = new Date()
  // 优先使用 API 调用实际返回的通道 ID，兜底用 resolveAutoChannelId
  const resolvedChannel = channel || resolveAutoChannelId('auto')
  const taskDoc = {
    requestId: 'api-' + crypto.randomBytes(8).toString('hex'),
    operatorId: userId || 'unknown',
    source: 'api',
    referenceImages: [],   // 异步填充：base64 存 GridFS 后转为 fileId
    items: [{
      taskType: taskType,
      status: status === 'succeeded' ? 'completed' : 'failed',
      prompt: extra.prompt || null,                 // 保存实际使用的 prompt
      startedAt: startTime,
      completedAt: now,
    }],
    options: {
      channel: resolvedChannel,
      userContext: extra.userContext || '',          // 保存用户调教参数
    },
    modelUsed: model || null,
    status: status,
    progress: 100,
    startedAt: startTime,
    completedAt: now,
  }

    // 统一异步处理：保存结果图片 + 参考图到 GridFS，最后创建任务记录
    ; (async () => {
      try {
        // 1. 保存结果图片到 GridFS
        if (imageDataUrl && status === 'succeeded') {
          try {
            const fileId = await imageProcessor.saveBase64ToGridFS(imageDataUrl, `furniai-${taskType}`)
            taskDoc.items[0].resultFileId = fileId
          } catch (e) {
            console.warn('[FurnIAI] 单次调用图片存储失败:', e.message)
            // GridFS 保存失败 → 降级 item 状态为 failed，避免"完成但无图片"的矛盾状态
            taskDoc.items[0].status = 'failed'
            taskDoc.items[0].error = '图片存储失败: ' + e.message
            taskDoc.status = 'failed'
          }
        }

        // 2. 保存参考图到 GridFS（base64/data URL → GridFS fileId，HTTP URL 和短字符串 fileId 直接透传）
        if (extra.referenceImages && extra.referenceImages.length > 0) {
          for (const ref of extra.referenceImages) {
            const imgData = typeof ref === 'object' ? ref.data : ref
            if (!imgData) continue
            try {
              if (imgData.startsWith('http://') || imgData.startsWith('https://')) {
                // HTTP URL → 直接存为 URL 引用
                taskDoc.referenceImages.push({ url: imgData })
              } else if (imgData.startsWith('data:') || (imgData.length > 200 && !imgData.includes('/'))) {
                // base64 / data URL → 存入 GridFS，转为 fileId
                const dataUrl = imgData.startsWith('data:') ? imgData : imageProcessor.toDataUrl(imgData)
                const refFileId = await imageProcessor.saveBase64ToGridFS(dataUrl, 'furniai-ref')
                taskDoc.referenceImages.push({ data: refFileId })
              } else {
                // 短字符串（可能是 GridFS fileId）→ 直接透传
                taskDoc.referenceImages.push({ data: imgData })
              }
            } catch (e) {
              console.warn('[FurnIAI] 参考图存储失败:', e.message)
            }
          }
        }
      } catch (e) {
        console.warn('[FurnIAI] 图片处理异常:', e.message)
      }

      // 创建任务前写入 timeline（单次调用无队列流程，在此一次性写入完整日志）
      const elapsed = ((now - startTime) / 1000).toFixed(1)
      taskDoc.timeline = [
        { ts: startTime, phase: 'received', msg: `API 单次调用 | 类型=${taskType} | 通道=${resolvedChannel} | 来源=api` },
        { ts: startTime, phase: 'api_call', msg: `调用 Gemini API | 模型=${model || '未知'}` },
        { ts: now, phase: status === 'succeeded' ? 'task_completed' : 'task_failed', msg: status === 'succeeded' ? `任务完成 | 耗时=${elapsed}s | 模型=${model || '未知'}` : `任务失败 | 耗时=${elapsed}s` },
      ]

      FurniaiTask.create(taskDoc).catch(e => console.error('[FurnIAI] 任务记录创建失败:', e.message))
    })()
}

// ==================== 分析家具图片 ====================
exports.analyze = async (req, res) => {
  try {
    const { image } = req.body
    if (!image) return res.status(400).json(errorResponse('Missing image'))

    const base64 = await imageProcessor.normalizeImageInput(image)
    const prompt = promptBuilder.buildAnalyzePrompt()
    const result = await geminiClient.analyzeWithText(prompt, base64)

    let jsonStr = result.text.replace(/```json\s*/gi, '').replace(/```\s*/g, '').trim()
    let analysis
    try {
      analysis = JSON.parse(jsonStr)
    } catch (parseErr) {
      analysis = {
        category: 'OTHER',
        specificType: 'Unknown',
        materials: [],
        style: 'Unknown',
        primaryColor: 'Unknown',
        sizeEstimate: 'M',
        rawText: result.text,
      }
    }

    return res.json(successResponse(analysis, 'Analysis complete'))
  } catch (err) {
    console.error('[FurnIAI] analyze error:', err.message)
    return res.status(500).json(errorResponse('Analysis failed: ' + err.message))
  }
}

// ==================== 单张生图 ====================
exports.generate = async (req, res) => {
  try {
    const startTime = new Date()
    const { image, taskType, analysis, options = {} } = req.body
    if (!image) return res.status(400).json(errorResponse('Missing image'))
    if (!taskType) return res.status(400).json(errorResponse('Missing taskType'))

    const base64 = await imageProcessor.normalizeImageInput(image)
    const prompt = promptBuilder.buildVisualPrompt(taskType, analysis || {}, options)

    const result = await geminiClient.generateImage(prompt, base64, {
      enableHD: options.enableHD,
    })

    const responseData = { text: result.text }
    if (result.image) {
      responseData.image = imageProcessor.toDataUrl(result.image)
    }

    // 异步更新调用统计（平台密钥 or JWT）
    if (req.platformKey) {
      req.platformKey.recordSuccess(promptBuilder.calculateCreditCost(taskType)).catch(e => console.error('[FurnIAI] 平台统计更新失败:', e.message))
    } else {
      jwtCounter.recordSuccess().catch(e => console.error('[FurnIAI] JWT统计更新失败:', e.message))
    }

    // 异步记录任务（含图片存储），传入实际使用的通道、模型和输入参数
    logSingleCallTask(req.userId, taskType, 'succeeded', startTime, result.channel, result.model, responseData.image, {
      prompt,
      referenceImages: [{ data: req.body.image }],
      userContext: options.userContext || '',
    })

    return res.json(successResponse(responseData, 'Generation complete'))
  } catch (err) {
    // 异步记录调用失败
    if (req.platformKey) {
      req.platformKey.recordFailure().catch(e => console.error('[FurnIAI] 平台统计更新失败:', e.message))
    } else {
      jwtCounter.recordFailure().catch(e => console.error('[FurnIAI] JWT统计更新失败:', e.message))
    }
    logSingleCallTask(req.userId, req.body?.taskType || 'unknown', 'failed', startTime, null, null, null, {
      prompt: req.body?.image ? promptBuilder.buildVisualPrompt(req.body.taskType || 'generate', {}, req.body.options || {}) : null,
      referenceImages: req.body?.image ? [{ data: req.body.image }] : [],
    })
    console.error('[FurnIAI] generate error:', err.message)
    return res.status(500).json(errorResponse('Generation failed: ' + err.message))
  }
}

// ==================== 双图融合 ====================
exports.fuse = async (req, res) => {
  try {
    const startTime = new Date()
    const { sourceImage, targetImage, fusionMode, instruction } = req.body
    if (!sourceImage || !targetImage) return res.status(400).json(errorResponse('Missing sourceImage or targetImage'))

    const srcBase64 = await imageProcessor.normalizeImageInput(sourceImage)
    const tgtBase64 = await imageProcessor.normalizeImageInput(targetImage)
    // 优先使用 fusionMode 枚举，兼容旧版 instruction 字段
    const prompt = promptBuilder.buildFusionPrompt(fusionMode || instruction || 'default')

    const result = await geminiClient.generateImage(prompt, srcBase64, {
      secondImageBase64: tgtBase64,
    })

    const responseData = { text: result.text }
    if (result.image) {
      responseData.image = imageProcessor.toDataUrl(result.image)
    }

    // 异步更新调用统计
    if (req.platformKey) {
      req.platformKey.recordSuccess(promptBuilder.calculateCreditCost('fuse')).catch(e => console.error('[FurnIAI] 平台统计更新失败:', e.message))
    } else {
      jwtCounter.recordSuccess().catch(e => console.error('[FurnIAI] JWT统计更新失败:', e.message))
    }

    // 异步记录任务，传入实际使用的通道、模型和输入参数
    logSingleCallTask(req.userId, 'fuse', 'succeeded', startTime, result.channel, result.model, responseData.image, {
      prompt,
      referenceImages: [{ data: req.body.sourceImage }, { data: req.body.targetImage }],
    })

    return res.json(successResponse(responseData, 'Fusion complete'))
  } catch (err) {
    if (req.platformKey) {
      req.platformKey.recordFailure().catch(e => console.error('[FurnIAI] 平台统计更新失败:', e.message))
    } else {
      jwtCounter.recordFailure().catch(e => console.error('[FurnIAI] JWT统计更新失败:', e.message))
    }
    logSingleCallTask(req.userId, 'fuse', 'failed', startTime, null, null, null, {
      referenceImages: [{ data: req.body?.sourceImage }, { data: req.body?.targetImage }].filter(r => r.data),
    })
    console.error('[FurnIAI] fuse error:', err.message)
    return res.status(500).json(errorResponse('Fusion failed: ' + err.message))
  }
}

// ==================== 材质分析 ====================
exports.analyzeMaterial = async (req, res) => {
  try {
    const { image } = req.body
    if (!image) return res.status(400).json(errorResponse('Missing image'))

    const base64 = await imageProcessor.normalizeImageInput(image)
    const prompt = promptBuilder.buildMaterialAnalyzePrompt()
    const result = await geminiClient.analyzeWithText(prompt, base64)

    let parsed
    try {
      const jsonMatch = result.text.match(/\{[\s\S]*?\}/)
      parsed = jsonMatch ? JSON.parse(jsonMatch[0]) : { name: 'Unknown', category: 'Other', tags: [] }
    } catch {
      parsed = { name: 'Unknown', category: 'Other', tags: [], rawText: result.text }
    }

    return res.json(successResponse(parsed, 'Material analysis complete'))
  } catch (err) {
    console.error('[FurnIAI] analyzeMaterial error:', err.message)
    return res.status(500).json(errorResponse('Material analysis failed: ' + err.message))
  }
}

// ==================== 材质贴图替换 ====================
exports.applyMaterial = async (req, res) => {
  try {
    const startTime = new Date()
    const { productImage, materialImage, materialName, targetPart, excludeParts } = req.body
    if (!productImage || !materialImage) return res.status(400).json(errorResponse('Missing productImage or materialImage'))

    const prodBase64 = await imageProcessor.normalizeImageInput(productImage)
    const matBase64 = await imageProcessor.normalizeImageInput(materialImage)
    const prompt = promptBuilder.buildMaterialApplyPrompt(materialName, targetPart, excludeParts)

    const result = await geminiClient.generateImage(prompt, prodBase64, {
      secondImageBase64: matBase64,
    })

    const responseData = { text: result.text }
    if (result.image) {
      responseData.image = imageProcessor.toDataUrl(result.image)
    }

    // 异步更新调用统计
    if (req.platformKey) {
      req.platformKey.recordSuccess(promptBuilder.calculateCreditCost('material-apply')).catch(e => console.error('[FurnIAI] 平台统计更新失败:', e.message))
    } else {
      jwtCounter.recordSuccess().catch(e => console.error('[FurnIAI] JWT统计更新失败:', e.message))
    }

    // 异步记录任务，传入实际使用的通道、模型和输入参数
    logSingleCallTask(req.userId, 'material-apply', 'succeeded', startTime, result.channel, result.model, responseData.image, {
      prompt,
      referenceImages: [{ data: req.body.productImage }, { data: req.body.materialImage }],
    })

    return res.json(successResponse(responseData, 'Material applied'))
  } catch (err) {
    if (req.platformKey) {
      req.platformKey.recordFailure().catch(e => console.error('[FurnIAI] 平台统计更新失败:', e.message))
    } else {
      jwtCounter.recordFailure().catch(e => console.error('[FurnIAI] JWT统计更新失败:', e.message))
    }
    logSingleCallTask(req.userId, 'material-apply', 'failed', startTime, null, null, null, {
      referenceImages: [{ data: req.body?.productImage }, { data: req.body?.materialImage }].filter(r => r.data),
    })
    console.error('[FurnIAI] applyMaterial error:', err.message)
    return res.status(500).json(errorResponse('Material application failed: ' + err.message))
  }
}

// ==================== 家具部件检测 ====================
exports.detectElements = async (req, res) => {
  try {
    const { image, lang = 'en' } = req.body
    if (!image) return res.status(400).json(errorResponse('Missing image'))

    const base64 = await imageProcessor.normalizeImageInput(image)
    const prompt = promptBuilder.buildElementDetectPrompt(lang)
    const result = await geminiClient.analyzeWithText(prompt, base64)

    let elements = []
    try {
      let text = result.text.replace(/```json\s*/gi, '').replace(/```\s*/g, '').trim()
      elements = JSON.parse(text)
      elements = elements.filter(el =>
        el.label && Array.isArray(el.box_2d) && el.box_2d.length === 4 &&
        el.box_2d[0] < el.box_2d[2] && el.box_2d[1] < el.box_2d[3]
      )
    } catch {
      elements = []
    }

    return res.json(successResponse(elements, `Detected ${elements.length} elements`))
  } catch (err) {
    console.error('[FurnIAI] detectElements error:', err.message)
    return res.status(500).json(errorResponse('Element detection failed: ' + err.message))
  }
}

// ==================== AI 修图 ====================
exports.edit = async (req, res) => {
  try {
    const startTime = new Date()
    const { image, instruction, referenceImage } = req.body
    if (!image) return res.status(400).json(errorResponse('Missing image'))
    if (!instruction) return res.status(400).json(errorResponse('Missing instruction'))

    const base64 = await imageProcessor.normalizeImageInput(image)
    let refBase64 = null
    if (referenceImage) {
      refBase64 = await imageProcessor.normalizeImageInput(referenceImage)
    }

    const prompt = promptBuilder.buildEditPrompt(instruction, !!refBase64)

    const result = await geminiClient.generateImage(prompt, base64, {
      secondImageBase64: refBase64,
    })

    const responseData = { text: result.text }
    if (result.image) {
      responseData.image = imageProcessor.toDataUrl(result.image)
    }

    // 异步更新调用统计
    if (req.platformKey) {
      req.platformKey.recordSuccess(promptBuilder.calculateCreditCost('edit')).catch(e => console.error('[FurnIAI] 平台统计更新失败:', e.message))
    } else {
      jwtCounter.recordSuccess().catch(e => console.error('[FurnIAI] JWT统计更新失败:', e.message))
    }

    // 异步记录任务，传入实际使用的通道、模型和所有输入参数（image + 可选 referenceImage）
    const editRefImages = [{ data: req.body.image }]
    if (req.body.referenceImage) editRefImages.push({ data: req.body.referenceImage })
    logSingleCallTask(req.userId, 'edit', 'succeeded', startTime, result.channel, result.model, responseData.image, {
      prompt,
      referenceImages: editRefImages,
    })

    return res.json(successResponse(responseData, 'Edit complete'))
  } catch (err) {
    if (req.platformKey) {
      req.platformKey.recordFailure().catch(e => console.error('[FurnIAI] 平台统计更新失败:', e.message))
    } else {
      jwtCounter.recordFailure().catch(e => console.error('[FurnIAI] JWT统计更新失败:', e.message))
    }
    const editRefImagesFail = []
    if (req.body?.image) editRefImagesFail.push({ data: req.body.image })
    if (req.body?.referenceImage) editRefImagesFail.push({ data: req.body.referenceImage })
    logSingleCallTask(req.userId, 'edit', 'failed', startTime, null, null, null, {
      referenceImages: editRefImagesFail,
    })
    console.error('[FurnIAI] edit error:', err.message)
    return res.status(500).json(errorResponse('Edit failed: ' + err.message))
  }
}

// ==================== Excel 表头分析 ====================
exports.analyzeExcelHeaders = async (req, res) => {
  try {
    const { headers } = req.body
    if (!headers || !Array.isArray(headers) || headers.length === 0) {
      return res.status(400).json(errorResponse('Missing or empty headers array'))
    }

    const prompt = promptBuilder.buildExcelHeaderPrompt(headers)
    const result = await geminiClient.analyzeWithText(prompt)

    let parsed
    try {
      let text = result.text.replace(/```json\s*/gi, '').replace(/```\s*/g, '').trim()
      parsed = JSON.parse(text)
    } catch {
      parsed = { usefulColumns: headers, ignoreColumns: [], columnTypes: {} }
    }

    return res.json(successResponse(parsed, 'Header analysis complete'))
  } catch (err) {
    console.error('[FurnIAI] analyzeExcelHeaders error:', err.message)
    return res.status(500).json(errorResponse('Header analysis failed: ' + err.message))
  }
}

// ==================== Excel 行解析 ====================
exports.parseExcelRow = async (req, res) => {
  try {
    const { rowData } = req.body
    if (!rowData || typeof rowData !== 'object') {
      return res.status(400).json(errorResponse('Missing or invalid rowData'))
    }

    const prompt = promptBuilder.buildExcelRowPrompt(rowData)
    const result = await geminiClient.analyzeWithText(prompt)

    let parsed
    try {
      let text = result.text.replace(/```json\s*/gi, '').replace(/```\s*/g, '').trim()
      parsed = JSON.parse(text)
    } catch {
      parsed = { productName: '', notes: 'Parse failed', rawText: result.text }
    }

    return res.json(successResponse(parsed, 'Row parse complete'))
  } catch (err) {
    console.error('[FurnIAI] parseExcelRow error:', err.message)
    return res.status(500).json(errorResponse('Row parse failed: ' + err.message))
  }
}

// ==================== 批量任务：提交 ====================
exports.batchSubmit = async (req, res) => {
  try {
    const { requestId, referenceImages, taskTypes, options = {} } = req.body

    if (!referenceImages || !Array.isArray(referenceImages) || referenceImages.length === 0) {
      return res.status(400).json(errorResponse('Missing referenceImages'))
    }
    if (!taskTypes || !Array.isArray(taskTypes) || taskTypes.length === 0) {
      return res.status(400).json(errorResponse('Missing taskTypes'))
    }

    // 幂等检查
    if (requestId) {
      const tenMinAgo = new Date(Date.now() - 10 * 60 * 1000)
      const existing = await FurniaiTask.findOne({ requestId, createdAt: { $gte: tenMinAgo } })
      if (existing) {
        return res.json(successResponse({
          taskId: existing._id,
          status: existing.status,
          progress: existing.progress,
          duplicate: true,
        }, 'Task already exists (idempotent)'))
      }
    }

    const items = taskTypes.map(type => ({
      taskType: type,
      status: 'pending',
      options: {},
    }))

    const task = await FurniaiTask.create({
      requestId: requestId || `auto_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      operatorId: req.user._id || req.userId,
      source: 'furniai',
      referenceImages: referenceImages.map(img =>
        typeof img === 'string' ? { data: img } : img
      ),
      items,
      options: {
        style: options.style || '',
        userContext: options.userContext || '',
        enableHD: options.enableHD || false,
        lang: options.lang || 'en',
        // 将 auto 解析为实际通道 ID，确保绑定到具体通道
        channel: resolveAutoChannelId(options.channel),
      },
    })

    console.log(`[FurnIAI] Batch created: taskId=${task._id}, types=${taskTypes.join(',')}`)

    // 任务创建即写入 timeline
    taskQueue.pushTimeline(task._id, 'furniai', 'received', `API 收到批量任务请求 | requestId=${task.requestId} | 类型=${taskTypes.join(',')} | 参考图=${referenceImages.length}张 | 来源=${req.platformKey?.name || 'JWT'}`)

    // 异步入队
    setImmediate(() => taskQueue.enqueue(task._id))

    return res.status(201).json(successResponse({
      taskId: task._id,
      status: 'queued',
      progress: 0,
      totalItems: items.length,
    }, 'Task submitted'))
  } catch (err) {
    console.error('[FurnIAI] batchSubmit error:', err.message)
    return res.status(500).json(errorResponse('Submit failed: ' + err.message))
  }
}

// ==================== 批量任务：查询状态 ====================
exports.batchGet = async (req, res) => {
  try {
    const { taskId } = req.params
    const task = await FurniaiTask.findById(taskId).lean()
    if (!task) return res.status(404).json(errorResponse('Task not found'))

    return res.json(successResponse({
      taskId: task._id,
      requestId: task.requestId,
      status: task.status,
      progress: task.progress,
      items: task.items.map(item => ({
        id: item._id,
        taskType: item.taskType,
        status: item.status,
        resultFileId: item.resultFileId,
        error: item.error,
      })),
      error: task.error,
      createdAt: task.createdAt,
      completedAt: task.completedAt,
    }))
  } catch (err) {
    console.error('[FurnIAI] batchGet error:', err.message)
    return res.status(500).json(errorResponse('Query failed'))
  }
}

// ==================== 批量任务：列表 ====================
exports.batchList = async (req, res) => {
  try {
    const { page = 1, pageSize = 20 } = req.query
    const query = { operatorId: req.user._id || req.userId }

    const total = await FurniaiTask.countDocuments(query)
    const tasks = await FurniaiTask.find(query)
      .sort({ createdAt: -1 })
      .skip((page - 1) * pageSize)
      .limit(parseInt(pageSize))
      .lean()

    const list = tasks.map(t => ({
      taskId: t._id,
      status: t.status,
      progress: t.progress,
      itemsSummary: {
        total: t.items.length,
        completed: t.items.filter(i => i.status === 'completed').length,
        failed: t.items.filter(i => i.status === 'failed').length,
      },
      createdAt: t.createdAt,
      completedAt: t.completedAt,
    }))

    return res.json(paginatedResponse(list, total, page, pageSize))
  } catch (err) {
    console.error('[FurnIAI] batchList error:', err.message)
    return res.status(500).json(errorResponse('List failed'))
  }
}

// ==================== 批量任务：重试 ====================
exports.batchRetry = async (req, res) => {
  try {
    const { taskId } = req.params
    const task = await FurniaiTask.findById(taskId)
    if (!task) return res.status(404).json(errorResponse('Task not found'))

    if (task.status !== 'succeeded' && task.status !== 'failed') {
      return res.status(400).json(errorResponse(`Cannot retry task with status: ${task.status}`))
    }

    let resetCount = 0
    for (const item of task.items) {
      if (item.status === 'failed') {
        item.status = 'pending'
        item.error = null
        item.resultFileId = null
        item.resultBase64 = null
        item.startedAt = null
        item.completedAt = null
        resetCount++
      }
    }

    if (resetCount === 0) {
      return res.status(400).json(errorResponse('No failed items to retry'))
    }

    await FurniaiTask.updateOne({ _id: taskId }, {
      $set: {
        status: 'queued',
        progress: 0,
        error: null,
        completedAt: null,
        retryCount: task.retryCount + 1,
        updatedAt: new Date()
      }
    });
    task.retryCount += 1;

    // 重试事件写入 timeline
    taskQueue.pushTimeline(task._id, 'furniai', 'retry', `任务重试（第${task.retryCount}次）| 重置 ${resetCount} 个失败子项`)

    setImmediate(() => taskQueue.enqueue(task._id))

    return res.json(successResponse({
      taskId: task._id,
      status: 'queued',
      resetItems: resetCount,
      retryCount: task.retryCount,
    }, 'Retry submitted'))
  } catch (err) {
    console.error('[FurnIAI] batchRetry error:', err.message)
    return res.status(500).json(errorResponse('Retry failed'))
  }
}

// ==================== 批量任务：取消 ====================
exports.batchCancel = async (req, res) => {
  try {
    const { taskId } = req.params
    const task = await FurniaiTask.findById(taskId)
    if (!task) return res.status(404).json(errorResponse('Task not found'))

    if (task.status === 'succeeded' || task.status === 'canceled') {
      return res.status(400).json(errorResponse(`Cannot cancel task with status: ${task.status}`))
    }

    await FurniaiTask.updateOne({ _id: taskId }, {
      $set: {
        status: 'canceled',
        updatedAt: new Date()
      }
    });

    return res.json(successResponse({ taskId: task._id, status: 'canceled' }, 'Task canceled'))
  } catch (err) {
    console.error('[FurnIAI] batchCancel error:', err.message)
    return res.status(500).json(errorResponse('Cancel failed'))
  }
}

// ==================== 配置查询（公开） ====================
exports.getConfig = async (req, res) => {
  try {
    return res.json(successResponse({
      creditCosts: promptBuilder.CREDIT_COSTS,
      multiViewSubtypes: promptBuilder.MULTI_VIEW_SUBTYPES,
      gemini: geminiClient.getConfig(),
      queue: taskQueue.getQueueStats(),
    }, 'Config loaded'))
  } catch (err) {
    return res.status(500).json(errorResponse('Config failed'))
  }
}

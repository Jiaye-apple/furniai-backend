/**
 * FurnIAI — AI Controller
 * REST 接口控制器，处理素材管理、AI 生成、积分管理、场景模板管理、配置数据、使用到商品
 */
const AiCredit = require('../models/AiCredit')
const AiMaterial = require('../models/AiMaterial')
const SceneTemplate = require('../models/SceneTemplate')
const { successResponse, errorResponse, paginatedResponse } = require('../utils/response')
const geminiProxy = require('../services/geminiProxyService')
const jwtCounter = require('../utils/jwtCounter')

// ========== 素材管理 ==========

exports.getMaterials = async (req, res) => {
  try {
    const { type, page = 1, pageSize = 20 } = req.query
    const query = { userId: req.userId }
    if (type) query.type = type

    const total = await AiMaterial.countDocuments(query)
    const materials = await AiMaterial.find(query)
      .sort({ createdAt: -1 })
      .skip((page - 1) * pageSize)
      .limit(parseInt(pageSize))
      .lean()

    return res.json(paginatedResponse(materials, total, page, pageSize))
  } catch (err) {
    console.error('[AI] getMaterials error:', err)
    return res.status(500).json(errorResponse('获取素材列表失败'))
  }
}

exports.saveMaterial = async (req, res) => {
  try {
    const { title, type, image, thumbnail, tags, sourceType, sourceParams, width, height } = req.body
    if (!title || !type || !image) {
      return res.status(400).json(errorResponse('缺少必要参数'))
    }

    const material = await AiMaterial.create({
      userId: req.userId,
      title,
      type,
      image,
      thumbnail: thumbnail || '',
      tags: tags || [],
      sourceType: sourceType || 'generate',
      sourceParams: sourceParams || {},
      width: width || 0,
      height: height || 0
    })

    return res.json(successResponse(material, '素材保存成功'))
  } catch (err) {
    console.error('[AI] saveMaterial error:', err)
    return res.status(500).json(errorResponse('保存素材失败'))
  }
}

exports.deleteMaterial = async (req, res) => {
  try {
    const { id } = req.params
    const material = await AiMaterial.findOneAndDelete({ _id: id, userId: req.userId })
    if (!material) {
      return res.status(404).json(errorResponse('素材不存在'))
    }
    return res.json(successResponse(null, '删除成功'))
  } catch (err) {
    console.error('[AI] deleteMaterial error:', err)
    return res.status(500).json(errorResponse('删除素材失败'))
  }
}

exports.batchDeleteMaterials = async (req, res) => {
  try {
    const { ids } = req.body
    if (!ids || !Array.isArray(ids) || ids.length === 0) {
      return res.status(400).json(errorResponse('请选择要删除的素材'))
    }

    const result = await AiMaterial.deleteMany({ _id: { $in: ids }, userId: req.userId })
    return res.json(successResponse({ deletedCount: result.deletedCount }, `成功删除 ${result.deletedCount} 个素材`))
  } catch (err) {
    console.error('[AI] batchDeleteMaterials error:', err)
    return res.status(500).json(errorResponse('批量删除失败'))
  }
}

// ========== AI 生成 ==========

exports.analyzeImage = async (req, res) => {
  try {
    const { image } = req.body
    if (!image) {
      return res.status(400).json(errorResponse('请提供图片'))
    }

    // 扣积分
    const credit = await AiCredit.getOrCreate(req.userId)
    const cost = geminiProxy.calculateCreditCost('analyze')
    await credit.consume(cost, 'AI图片分析')

    const analysis = await geminiProxy.analyzeFurnitureImage(image)

    // 异步更新调用统计（成功）
    if (req.platformKey) {
      req.platformKey.recordSuccess(cost).catch(e => console.error('[AI] 平台统计更新失败:', e.message))
    } else {
      jwtCounter.recordSuccess().catch(e => console.error('[AI] JWT统计更新失败:', e.message))
    }

    return res.json(successResponse({ analysis, creditCost: cost, creditBalance: credit.balance }))
  } catch (err) {
    console.error('[AI] analyzeImage error:', err)
    // 异步更新调用统计（失败）
    if (req.platformKey) {
      req.platformKey.recordFailure().catch(e => console.error('[AI] 平台统计更新失败:', e.message))
    } else {
      jwtCounter.recordFailure().catch(e => console.error('[AI] JWT统计更新失败:', e.message))
    }
    if (err.message === '积分余额不足') {
      return res.status(400).json(errorResponse('积分余额不足'))
    }
    return res.status(500).json(errorResponse('AI分析失败: ' + err.message))
  }
}

exports.generateImage = async (req, res) => {
  try {
    const { type, image, options = {} } = req.body
    if (!type || !image) {
      return res.status(400).json(errorResponse('缺少必要参数'))
    }

    // 计算积分消耗
    const cost = geminiProxy.calculateCreditCost(type, options)
    const credit = await AiCredit.getOrCreate(req.userId)
    await credit.consume(cost, `AI生成-${type}`, '')

    // 调用 AI 生成
    const result = await geminiProxy.generateFurnitureVisual(image, type, options)

    // 异步更新调用统计（成功）
    if (req.platformKey) {
      req.platformKey.recordSuccess(cost).catch(e => console.error('[AI] 平台统计更新失败:', e.message))
    } else {
      jwtCounter.recordSuccess().catch(e => console.error('[AI] JWT统计更新失败:', e.message))
    }

    return res.json(successResponse({
      image: result.image ? `data:image/png;base64,${result.image}` : null,
      text: result.text,
      creditCost: cost,
      creditBalance: credit.balance
    }))
  } catch (err) {
    console.error('[AI] generateImage error:', err)
    // 异步更新调用统计（失败）
    if (req.platformKey) {
      req.platformKey.recordFailure().catch(e => console.error('[AI] 平台统计更新失败:', e.message))
    } else {
      jwtCounter.recordFailure().catch(e => console.error('[AI] JWT统计更新失败:', e.message))
    }
    if (err.message === '积分余额不足') {
      return res.status(400).json(errorResponse('积分余额不足'))
    }
    return res.status(500).json(errorResponse('AI生成失败: ' + err.message))
  }
}

exports.uploadImage = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json(errorResponse('请上传图片'))
    }

    const base64 = req.file.buffer.toString('base64')
    const mimeType = req.file.mimetype
    const imageData = `data:${mimeType};base64,${base64}`

    return res.json(successResponse({
      image: imageData,
      originalName: req.file.originalname,
      size: req.file.size,
      mimeType
    }))
  } catch (err) {
    console.error('[AI] uploadImage error:', err)
    return res.status(500).json(errorResponse('上传失败'))
  }
}

// ========== 积分 ==========

exports.getCredits = async (req, res) => {
  try {
    const credit = await AiCredit.getOrCreate(req.userId)
    return res.json(successResponse({
      balance: credit.balance,
      totalConsumed: credit.totalConsumed,
      totalRecharged: credit.totalRecharged
    }))
  } catch (err) {
    console.error('[AI] getCredits error:', err)
    return res.status(500).json(errorResponse('获取积分信息失败'))
  }
}

exports.getCreditHistory = async (req, res) => {
  try {
    const { page = 1, pageSize = 20 } = req.query
    const credit = await AiCredit.getOrCreate(req.userId)

    const history = credit.history
      .sort((a, b) => b.createdAt - a.createdAt)
      .slice((page - 1) * pageSize, page * pageSize)

    return res.json(paginatedResponse(history, credit.history.length, page, pageSize))
  } catch (err) {
    console.error('[AI] getCreditHistory error:', err)
    return res.status(500).json(errorResponse('获取积分记录失败'))
  }
}

// ========== 场景模板 ==========

exports.getSceneTemplates = async (req, res) => {
  try {
    const { style, space, keyword, page = 1, pageSize = 20 } = req.query
    const query = { status: 'active' }
    if (style) query.style = style
    if (space) query.space = space
    if (keyword) {
      query.$or = [
        { name: { $regex: keyword, $options: 'i' } },
        { tags: { $in: [new RegExp(keyword, 'i')] } }
      ]
    }

    const total = await SceneTemplate.countDocuments(query)
    const templates = await SceneTemplate.find(query)
      .sort({ sortOrder: -1, createdAt: -1 })
      .skip((page - 1) * pageSize)
      .limit(parseInt(pageSize))
      .lean()

    return res.json(paginatedResponse(templates, total, page, pageSize))
  } catch (err) {
    console.error('[AI] getSceneTemplates error:', err)
    return res.status(500).json(errorResponse('获取场景模板失败'))
  }
}

exports.createSceneTemplate = async (req, res) => {
  try {
    const { name, style, space, image, thumbnail, orientation, popular, sortOrder, tags, description } = req.body
    if (!name || !style || !space || !image) {
      return res.status(400).json(errorResponse('缺少必要参数'))
    }

    const template = await SceneTemplate.create({
      name, style, space, image,
      thumbnail: thumbnail || '',
      orientation: orientation || 'landscape',
      popular: popular || false,
      sortOrder: sortOrder || 0,
      tags: tags || [],
      description: description || ''
    })

    return res.json(successResponse(template, '创建成功'))
  } catch (err) {
    console.error('[AI] createSceneTemplate error:', err)
    return res.status(500).json(errorResponse('创建场景模板失败'))
  }
}

exports.updateSceneTemplate = async (req, res) => {
  try {
    const { id } = req.params
    const template = await SceneTemplate.findByIdAndUpdate(id, req.body, { new: true })
    if (!template) {
      return res.status(404).json(errorResponse('模板不存在'))
    }
    return res.json(successResponse(template, '更新成功'))
  } catch (err) {
    console.error('[AI] updateSceneTemplate error:', err)
    return res.status(500).json(errorResponse('更新失败'))
  }
}

exports.deleteSceneTemplate = async (req, res) => {
  try {
    const { id } = req.params
    const template = await SceneTemplate.findByIdAndDelete(id)
    if (!template) {
      return res.status(404).json(errorResponse('模板不存在'))
    }
    return res.json(successResponse(null, '删除成功'))
  } catch (err) {
    console.error('[AI] deleteSceneTemplate error:', err)
    return res.status(500).json(errorResponse('删除失败'))
  }
}

// ========== 配置数据 ==========

exports.getStyleOptions = async (req, res) => {
  const styles = [
    { id: 'modern', name: '现代简约' },
    { id: 'nordic', name: '北欧风格' },
    { id: 'chinese', name: '新中式' },
    { id: 'light-luxury', name: '轻奢风' },
    { id: 'industrial', name: '工业风' },
    { id: 'japanese', name: '日式' }
  ]
  return res.json(successResponse(styles))
}

exports.getSpaceOptions = async (req, res) => {
  const spaces = [
    { id: 'living', name: '客厅' },
    { id: 'bedroom', name: '卧室' },
    { id: 'dining', name: '餐厅' },
    { id: 'study', name: '书房' },
    { id: 'balcony', name: '阳台' }
  ]
  return res.json(successResponse(spaces))
}

exports.getFabricOptions = async (req, res) => {
  const fabrics = [
    { id: 'italian-leather', name: '意大利头层牛皮', tag: '推荐', priceAdd: 800 },
    { id: 'nappa-leather', name: 'Nappa真皮', tag: '热门', priceAdd: 600 },
    { id: 'tech-fabric', name: '科技布', tag: '', priceAdd: 0 },
    { id: 'cotton-linen', name: '棉麻混纺', tag: '', priceAdd: 200 },
    { id: 'velvet', name: '丝绒', tag: '', priceAdd: 400 },
    { id: 'microfiber', name: '超纤皮', tag: '', priceAdd: 300 }
  ]
  return res.json(successResponse(fabrics))
}

exports.getColorOptions = async (req, res) => {
  const colors = [
    { id: 'mc-black', name: '黑色', color: '#1a1a1a' },
    { id: 'mc-dark-brown', name: '深棕', color: '#3d2b1f' },
    { id: 'mc-brown', name: '棕色', color: '#6b4423' },
    { id: 'mc-camel', name: '驼色', color: '#c19a6b' },
    { id: 'mc-gray', name: '灰色', color: '#808080' },
    { id: 'mc-olive', name: '橄榄绿', color: '#808000' },
    { id: 'mc-cream', name: '米白', color: '#f5f5dc' },
    { id: 'mc-tan', name: '浅棕', color: '#d2b48c' },
    { id: 'mc-charcoal', name: '炭灰', color: '#36454f' },
    { id: 'mc-navy', name: '藏青', color: '#000080' },
    { id: 'mc-burgundy', name: '酒红', color: '#800020' },
    { id: 'mc-sand', name: '沙色', color: '#c2b280' }
  ]
  return res.json(successResponse(colors))
}

// ========== 使用到商品 ==========

exports.useInProduct = async (req, res) => {
  try {
    const { materialIds, productId, specs, fabric, color, usageType } = req.body
    if (!materialIds || !productId || !usageType) {
      return res.status(400).json(errorResponse('缺少必要参数'))
    }

    // TODO: 实际将素材关联到商品的逻辑
    // 当前先记录操作日志
    console.log('[AI] useInProduct:', { userId: req.userId, materialIds, productId, specs, fabric, color, usageType })

    return res.json(successResponse({
      materialIds,
      productId,
      specs,
      fabric,
      color,
      usageType
    }, '素材已成功应用到商品'))
  } catch (err) {
    console.error('[AI] useInProduct error:', err)
    return res.status(500).json(errorResponse('操作失败'))
  }
}

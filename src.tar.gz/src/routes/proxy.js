/**
 * New API 中转路由 — 纯透传 + 平台密钥鉴权 + 大盘统计
 * 
 * 前端调用: POST https://hzh.sealos.run/proxy/v1/chat/completions
 * 本路由:   鉴权(pk-xxx) → 转发到 http://zx2.52youxi.cc:3000/v1/chat/completions → 记录统计
 * 
 * 统计规则：只有 POST /v1/chat/completions（生图请求）才记录任务和统计
 *          其他请求（如 GET /v1/models）只做透传，不记录
 */
const express = require('express')
const router = express.Router()
const axios = require('axios')
const { auth } = require('../middleware/auth')
const FurniaiTask = require('../models/FurniaiTask')
const crypto = require('crypto')
const configManager = require('../services/configManager')
const jwtCounter = require('../utils/jwtCounter')

// 动态获取当前活动的通道（考虑到 channelPriority 优先级）
function getActiveChannel() {
    const config = configManager.get()
    const mode = config?.channelMode || 'auto'
    const list = config?.channelPriority || []

    // 如果不是 auto，直接按 id 查找通道
    let activeId = mode
    if (mode === 'auto') {
        const firstActive = list.find(c => c.enabled)
        activeId = firstActive ? firstActive.id : 'concurrent'
    }

    const activeCh = list.find(c => c.id === activeId)
    // 如果找不到，返回一个空的结构防报错
    return activeCh || {}
}

/**
 * 获取所有已启用通道列表（按 channelPriority 排序），用于通道降级重试
 * @returns {Array<Object>} 已启用通道列表
 */
function getAllActiveChannels() {
    const config = configManager.get()
    const list = config?.channelPriority || []
    return list.filter(c => c.enabled)
}

function getProxyTarget() { return getActiveChannel().url || process.env.NEWAPI_TARGET || 'http://zx2.52youxi.cc:3000' }
function getProxyKey() { return getActiveChannel().apiKey || process.env.NEWAPI_KEY || '' }
function getProxyChannelName() { return getActiveChannel().name || '未知配置' }
function getProxyChannelId() { return getActiveChannel().id || 'auto' }

/**
 * 从请求体中提取 prompt 文本和输入图片 base64
 * 支持多种格式：OpenAI messages / 顶层 prompt / input 等
 * 纯内存读取操作，零延迟，不影响转发速度
 * @param {Object} body - req.body
 * @returns {{ promptText: string, inputImages: string[], imageUrls: string[], hasInputImages: boolean }}
 */
function extractMessagesInfo(body) {
    const result = { promptText: '', inputImages: [], imageUrls: [], hasInputImages: false }
    if (!body) return result

    const textParts = []
    const messages = body.messages

    // ── 1. 标准 OpenAI messages 格式 ──
    if (Array.isArray(messages)) {
        for (const msg of messages) {
            const content = msg.content
            if (!content) continue

            // 纯文本格式：content 是字符串
            if (typeof content === 'string') {
                textParts.push(content)
                continue
            }

            // 多模态格式：content 是数组 [{type:'text', text:...}, {type:'image_url', image_url:{url:...}}]
            if (Array.isArray(content)) {
                for (const part of content) {
                    if (part.type === 'text' && part.text) {
                        textParts.push(part.text)
                    } else if (part.type === 'image_url' && part.image_url?.url) {
                        const url = part.image_url.url
                        if (url.startsWith('data:image')) {
                            // base64 图片 → 存储到 GridFS
                            result.inputImages.push(url)
                        } else if (url.startsWith('http')) {
                            // 外部 URL 图片 → 仅记录 URL，不下载
                            result.imageUrls.push(url)
                        }
                    }
                }
            }
        }
    }

    // ── 2. 兜底：检查顶层 prompt / input 字段（非标准格式） ──
    if (textParts.length === 0) {
        if (typeof body.prompt === 'string' && body.prompt) textParts.push(body.prompt)
        if (typeof body.input === 'string' && body.input) textParts.push(body.input)

        // 兜底：如果就是个字符串的内容
        if (typeof messages === 'string' && messages) textParts.push(messages)

        // 兜底：如果 messages 是数组但全是各种奇怪格式
        if (Array.isArray(messages) && textParts.length === 0) {
            try {
                const str = JSON.stringify(messages)
                // 尝试用正则粗略提取文字
                const matches = str.match(/"text"\s*:\s*"([^"\\]*(?:\\.[^"\\]*)*)"/g)
                if (matches) {
                    matches.forEach(m => {
                        const v = m.match(/"text"\s*:\s*"(.*)"/)[1]
                        if (v) textParts.push(v)
                    })
                }
            } catch (e) {
                console.warn('[Proxy] 兜底提取信息异常', e)
            }
        }
    }

    result.promptText = textParts.join('\n').slice(0, 2000) // 截断过长 prompt，防止 DB 膨胀
    result.hasInputImages = result.inputImages.length > 0 || result.imageUrls.length > 0
    return result
}

/**
 * 在转发前创建 running 状态的任务记录
 * 管理面板可实时看到「运行中」的代理任务
 * @param {string} userId - 调用者标识
 * @param {string} model - 模型名称
 * @param {Date} startTime - 请求开始时间
 * @param {Object} extractedInfo - extractMessagesInfo 提取的信息
 * @returns {Promise<Object>} 创建的任务文档
 */
async function createProxyTask(userId, model, startTime, extractedInfo) {
    const channelId = getProxyChannelId()
    const channelName = getProxyChannelName()
    // 根据是否有输入图片判断任务类型：有图+文字指令 → edit，纯文字 → generate
    const taskType = extractedInfo?.hasInputImages ? 'edit' : 'generate'
    const taskDoc = await FurniaiTask.create({
        requestId: 'api-' + crypto.randomBytes(8).toString('hex'),
        operatorId: userId || 'unknown',
        source: 'api',
        items: [{
            taskType: taskType,
            status: 'processing', // 子项正在处理中
            startedAt: startTime,
            prompt: extractedInfo?.promptText || null, // 保存 prompt 文本，供后台详情展示
        }],
        options: {
            channel: channelId,
            model: model || 'unknown',
            userContext: extractedInfo?.promptText || '', // 同步保存到 userContext，前端详情弹窗会读取此字段
        },
        // 立即写入 modelUsed，任务列表/详情可以立即展示模型名
        modelUsed: model || null,
        status: 'running', // 任务运行中
        progress: 0,
        startedAt: startTime,
    })
    console.log(`[Proxy] 任务记录已创建(running): taskId=${taskDoc.requestId}, type=${taskType}, model=${model}, channel=${channelName}`)
    return taskDoc
}

/**
 * 转发完成后更新任务记录状态 + 保存输出图片 + 异步保存输入图片
 * 全部在响应返回给用户之后执行，不阻塞用户
 * @param {Object} taskDoc - createProxyTask 返回的任务文档
 * @param {string} status - 最终状态 succeeded/failed
 * @param {Buffer|null} responseBuffer - 响应体 Buffer（用于提取输出图片）
 * @param {string} errorMessage - 失败时的错误信息
 * @param {Object} extractedInfo - extractMessagesInfo 预提取的信息 { inputImages, imageUrls }
 * @param {Object} [channelInfo] - 最终使用的通道信息 { channelId, channelName, model }
 */
async function completeProxyTask(taskDoc, status, responseBuffer, errorMessage, extractedInfo, channelInfo) {
    if (!taskDoc) return
    const now = new Date()

    // 更新任务和子项状态
    // 构建要原子更新的基础字段
    const updateData = {
        status: status,
        progress: 100,
        completedAt: now,
        updatedAt: now,
        'items.0.status': status === 'succeeded' ? 'completed' : 'failed',
        'items.0.completedAt': now
    }

    // 如果通道发生了降级，更新任务记录中的通道和模型信息
    if (channelInfo) {
        if (!taskDoc.options) taskDoc.options = {}
        updateData['options.channel'] = channelInfo.channelId
        updateData.modelUsed = channelInfo.model
    }

    // 失败时保存详细错误信息，便于在任务详情中排查
    if (status === 'failed' && errorMessage) {
        updateData.error = errorMessage
        updateData['items.0.error'] = errorMessage
    }

    await FurniaiTask.updateOne({ _id: taskDoc._id }, { $set: updateData })

    const imageProcessor = require('../services/imageProcessor')
    const inputImages = extractedInfo?.inputImages || []
    const imageUrls = extractedInfo?.imageUrls || []

    // ── 异步保存输入图片到 GridFS + 外部 URL 记录（不阻塞，失败不影响任务状态） ──
    if (inputImages.length > 0 || imageUrls.length > 0) {
        (async () => {
            try {
                const refEntries = []
                // 1. base64 图片 → 保存到 GridFS
                for (const dataUrl of inputImages) {
                    try {
                        const fileId = await imageProcessor.saveBase64ToGridFS(dataUrl, 'proxy-input')
                        refEntries.push({ data: fileId })
                    } catch (e) {
                        console.warn(`[Proxy] 输入图片保存失败（跳过）: ${e.message}`)
                    }
                }
                // 2. 外部 URL 图片 → 直接记录 URL（不下载，避免阻塞）
                for (const url of imageUrls) {
                    refEntries.push({ url: url })
                }
                if (refEntries.length > 0) {
                    await FurniaiTask.updateOne(
                        { _id: taskDoc._id },
                        { $set: { referenceImages: refEntries } }
                    )
                    console.log(`[Proxy] 输入图片已保存: ${refEntries.length} 条(GridFS:${inputImages.length}, URL:${imageUrls.length}), taskId=${taskDoc.requestId}`)
                }
            } catch (e) {
                console.warn(`[Proxy] 输入图片批量保存异常: ${e.message}`)
            }
        })()
    }

    // ── 成功的生图请求：解析响应中的文本和图片 ──
    if (status === 'succeeded' && responseBuffer) {
        try {
            const respText = responseBuffer.toString('utf-8')
            const respJson = JSON.parse(respText)

            // ── 提取响应文本内容（无论是否有图片都保存） ──
            let responseTextContent = ''

            // OpenAI/Anthropic 格式：choices[0].message.content
            const content = respJson?.choices?.[0]?.message?.content || ''
            if (content) {
                // 去掉 base64 图片数据，只保留可读文本（避免文本字段过大）
                responseTextContent = content.replace(/data:image\/[^;]+;base64,[A-Za-z0-9+/=]+/g, '[图片数据已省略]').trim()
            }

            // Google 原生格式：candidates[].content.parts[].text
            if (!responseTextContent && respJson?.candidates) {
                const textParts = []
                for (const cand of (respJson.candidates || [])) {
                    for (const part of (cand.content?.parts || [])) {
                        if (part.text) textParts.push(part.text)
                    }
                }
                if (textParts.length > 0) responseTextContent = textParts.join('\n').trim()
            }

            // 截断过长文本（防止 DB 膨胀，保留前 2000 字符）
            if (responseTextContent.length > 2000) {
                responseTextContent = responseTextContent.substring(0, 2000) + '...[截断]'
            }

            // 保存响应文本到 resultText 字段
            if (responseTextContent) {
                await FurniaiTask.updateOne(
                    { _id: taskDoc._id },
                    { $set: { 'items.0.resultText': responseTextContent } }
                )
                console.log(`[Proxy] 响应文本已保存: taskId=${taskDoc.requestId}, 长度=${responseTextContent.length}`)
            }

            // ── 提取图片 base64 ──
            let imageBase64 = null

            // OpenAI/Anthropic 格式：content 中包含 data:image/...;base64,...
            const dataUrlMatch = content.match(/data:image\/(jpeg|png|webp);base64,([A-Za-z0-9+/=]+)/)
            if (dataUrlMatch) {
                imageBase64 = dataUrlMatch[2]
            }

            // Markdown 图片格式：![...](data:image/...;base64,...)
            if (!imageBase64) {
                const mdMatch = content.match(/!\[.*?\]\(data:image\/(jpeg|png|webp);base64,([^)]+)\)/)
                if (mdMatch) imageBase64 = mdMatch[2]
            }

            // OpenRouter 格式：choices[0].message.images[].image_url.url
            if (!imageBase64) {
                const images = respJson?.choices?.[0]?.message?.images
                if (images && Array.isArray(images) && images.length > 0) {
                    const dataUrl = images[0]?.image_url?.url || ''
                    if (dataUrl) {
                        const orMatch = dataUrl.match(/^data:image\/(jpeg|png|webp);base64,(.+)$/)
                        if (orMatch) {
                            imageBase64 = orMatch[2]
                        } else {
                            // URL 格式（非 base64），OpenRouter/Midjourney 可能会这样做
                            taskDoc.items[0].resultFileId = null // 因为是外部 URL，没有 GridFS fileId
                            taskDoc.items[0].resultBase64 = null
                            taskDoc.items[0].resultText = (taskDoc.items[0].resultText ? taskDoc.items[0].resultText + '\n\n' : '') + dataUrl
                        }
                    }
                }
            }

            // OpenAI DALL-E 格式: data[0].b64_json 或 url
            if (!imageBase64 && respJson?.data && Array.isArray(respJson.data) && respJson.data.length > 0) {
                const imgData = respJson.data[0]
                if (imgData.b64_json) {
                    imageBase64 = imgData.b64_json
                } else if (imgData.url) {
                    taskDoc.items[0].resultText = (taskDoc.items[0].resultText ? taskDoc.items[0].resultText + '\n\n' : '') + imgData.url
                }
            }

            // Google 原生格式：candidates[].content.parts[].inlineData.data
            if (!imageBase64 && respJson?.candidates) {
                for (const cand of respJson.candidates) {
                    for (const part of (cand.content?.parts || [])) {
                        const inlineData = part.inlineData || part.inline_data
                        if (inlineData?.data) {
                            imageBase64 = inlineData.data
                            break
                        }
                    }
                    if (imageBase64) break
                }
            }

            if (imageBase64) {
                // 存入 GridFS
                const dataUrl = imageProcessor.toDataUrl(imageBase64)
                const fileId = await imageProcessor.saveBase64ToGridFS(dataUrl, `proxy-${taskDoc.items[0].taskType}`)
                // 更新任务记录的 resultFileId
                await FurniaiTask.updateOne(
                    { _id: taskDoc._id },
                    { $set: { 'items.0.resultFileId': fileId } }
                )
                console.log(`[Proxy] 输出图片已保存到 GridFS: fileId=${fileId}, taskId=${taskDoc.requestId}`)
            } else {
                console.log(`[Proxy] 响应中未找到图片数据: taskId=${taskDoc.requestId}`)
            }
        } catch (e) {
            console.warn(`[Proxy] 响应解析/保存失败（不影响响应）: ${e.message}`)
        }
    }
}

/**
 * 对指定通道执行单次 axios 转发
 * @param {Object} ch - channelPriority 中的通道配置对象
 * @param {Object} req - Express 请求对象
 * @param {string} targetPath - 去除 /proxy 前缀后的路径
 * @param {string} model - 本次使用的模型名
 * @returns {Promise<{response: Object, targetUrl: string, finalModel: string}>} axios 响应
 */
async function _forwardToChannel(ch, req, targetPath, model) {
    const baseUrl = (ch.url || process.env.NEWAPI_TARGET || 'http://zx2.52youxi.cc:3000').replace(/\/+$/, '')
    let path = targetPath
    // 应对接口常常自带 /v1 后缀导致两重 /v1/v1 的问题
    if (baseUrl.endsWith('/v1') && path.startsWith('/v1/')) {
        path = path.substring(3)
    }
    const targetUrl = `${baseUrl}${path}`

    // 覆盖请求体中的 model
    const body = req.body ? { ...req.body, model } : req.body

    const apiTimeout = configManager.get('apiTimeoutMs') || 120000
    const axiosConfig = {
        method: req.method,
        url: targetUrl,
        headers: {
            'Content-Type': req.headers['content-type'] || 'application/json',
            'Authorization': `Bearer ${ch.apiKey || process.env.NEWAPI_KEY || ''}`,
        },
        timeout: apiTimeout,
        responseType: 'arraybuffer',
        validateStatus: () => true,
        maxContentLength: Infinity,
        maxBodyLength: Infinity,
    }
    if (['POST', 'PUT', 'PATCH'].includes(req.method)) {
        axiosConfig.data = body
    }

    const response = await axios(axiosConfig)
    return { response, targetUrl, finalModel: model }
}

// CORS 预检请求放行（OPTIONS 不走 auth，否则浏览器 preflight 会被 401 拦截）
router.options('/*', (req, res) => {
    res.set('Access-Control-Allow-Origin', req.headers.origin || '*')
    res.set('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS')
    res.set('Access-Control-Allow-Headers', 'Content-Type, Authorization')
    res.set('Access-Control-Max-Age', '86400')
    res.sendStatus(200)
})

// 所有代理路由都需要平台密钥鉴权
router.use(auth)

/**
 * 通用透传：所有路径 + 所有方法
 * /proxy/v1/chat/completions → 优先通道 → 失败时降级到备用模型/下一通道
 * /proxy/v1/models → 直接透传，不做降级
 */
router.all('/*', async (req, res) => {
    const startTime = new Date()
    // 只有 POST /v1/chat/completions 才是生图请求，需要统计和通道降级
    const isGenerateCall = req.method === 'POST' && req.originalUrl.includes('/chat/completions')
    // 生图请求：在转发前从 messages 中提取 prompt 文本和输入图片（纯内存读取，零延迟）
    const extractedInfo = isGenerateCall ? extractMessagesInfo(req.body) : null
    // 生图任务的预创建记录（用于管理面板实时展示 running 状态）
    let proxyTaskDoc = null

    // 去掉路由前缀，保留 /v1/... 路径
    const targetPath = req.originalUrl.replace(/^\/proxy/, '')

    // ── 非生图请求：保持原有单次转发逻辑（不做降级） ──
    if (!isGenerateCall) {
        try {
            const activeCh = getActiveChannel()
            const { response, targetUrl } = await _forwardToChannel(activeCh, req, targetPath, req.body?.model || 'unknown')
            console.log(`[Proxy] ${req.method} -> ${targetUrl} | 用户: ${req.userId}`)
            res.status(response.status)
            res.set('Access-Control-Allow-Origin', req.headers.origin || '*')
            const contentType = response.headers['content-type']
            if (contentType) res.set('Content-Type', contentType)
            res.send(Buffer.from(response.data))
        } catch (err) {
            console.error('[Proxy] 转发失败:', err.message)
            res.status(502).json({ error: 'Proxy Error', message: err.message })
        }
        return
    }

    // ── 生图请求：带通道降级重试的转发逻辑 ──
    const allChannels = getAllActiveChannels()
    const primaryCh = getActiveChannel()
    // 确定首选模型
    const originalModel = req.body?.model || 'unknown'
    const primaryModel = primaryCh.imageModel || originalModel

    // 先创建任务记录
    try {
        proxyTaskDoc = await createProxyTask(req.userId, primaryModel, startTime, extractedInfo)
    } catch (e) {
        console.warn('[Proxy] 创建任务记录失败（不阻塞请求）:', e.message)
    }

    // 构建要尝试的通道+模型列表：[ { ch, model, label }, ... ]
    const attempts = []
    for (const ch of allChannels) {
        // 主模型
        attempts.push({ ch, model: ch.imageModel || originalModel, label: `${ch.name}[主:${ch.imageModel || originalModel}]` })
        // 备用模型（如果配置了且不同于主模型）
        if (ch.backupImageModel && ch.backupImageModel !== ch.imageModel) {
            attempts.push({ ch, model: ch.backupImageModel, label: `${ch.name}[备用:${ch.backupImageModel}]` })
        }
    }

    // 如果没有任何可用通道，直接报错
    if (attempts.length === 0) {
        console.error('[Proxy] 没有可用的通道配置')
        res.status(502).json({ error: 'Proxy Error', message: '没有可用的通道配置' })
        completeProxyTask(proxyTaskDoc, 'failed', null, '没有可用的通道配置', extractedInfo)
        return
    }

    const errors = []

    for (let i = 0; i < attempts.length; i++) {
        const { ch, model, label } = attempts[i]
        try {
            console.log(`[Proxy] 生图转发尝试 ${i + 1}/${attempts.length}: ${label} | 用户: ${req.userId}`)
            const { response, targetUrl, finalModel } = await _forwardToChannel(ch, req, targetPath, model)

            const isSuccess = response.status >= 200 && response.status < 400

            if (isSuccess) {
                // ── 成功：返回响应 + 记录统计 ──
                res.status(response.status)
                res.set('Access-Control-Allow-Origin', req.headers.origin || '*')
                const contentType = response.headers['content-type']
                if (contentType) res.set('Content-Type', contentType)
                const dataBuffer = Buffer.from(response.data)
                res.send(dataBuffer)

                // 统计
                if (req.platformKey) {
                    req.platformKey.recordSuccess(20).catch(e => console.error('[Proxy] 平台统计更新失败:', e.message))
                } else {
                    jwtCounter.recordSuccess().catch(e => console.error('[Proxy] JWT统计更新失败:', e.message))
                }

                // 如果发生了降级（i > 0），日志提示
                if (i > 0) {
                    console.log(`[Proxy] ✅ 降级成功: 第 ${i + 1} 次尝试成功 (${label})`)
                }

                // 异步更新任务记录（含最终使用的通道信息）
                completeProxyTask(proxyTaskDoc, 'succeeded', dataBuffer, null, extractedInfo, {
                    channelId: ch.id, channelName: ch.name, model: finalModel,
                })
                return // 成功，结束
            }

            // 上游返回了非成功状态码 → 视为可降级的失败
            const errText = Buffer.from(response.data).toString('utf-8').slice(0, 300)
            const errMsg = `${label} 上游 HTTP ${response.status}: ${errText}`
            console.warn(`[Proxy] ${errMsg}`)
            errors.push(errMsg)
            // 继续尝试下一个通道

        } catch (err) {
            // 网络错误/超时 → 可降级
            const errMsg = `${label} ${err.message}`
            console.warn(`[Proxy] 通道失败: ${errMsg}`)
            errors.push(errMsg)
            // 继续尝试下一个通道
        }
    }

    // ── 所有通道都失败 ──
    const allErrors = errors.join('; ')
    console.error(`[Proxy] 所有通道均失败 (${attempts.length} 次尝试): ${allErrors}`)
    res.status(502).json({
        error: 'Proxy Error',
        message: `所有通道均失败: ${allErrors}`,
    })

    // 统计
    if (req.platformKey) {
        req.platformKey.recordFailure().catch(e => console.error('[Proxy] 平台统计更新失败:', e.message))
    } else {
        jwtCounter.recordFailure().catch(e => console.error('[Proxy] JWT统计更新失败:', e.message))
    }
    completeProxyTask(proxyTaskDoc, 'failed', null, `所有通道均失败: ${allErrors}`, extractedInfo)
})

module.exports = router

const express = require('express')
const cors = require('cors')

const app = express()

// CORS 中间件
app.use(cors({
  origin: (origin, callback) => {
    const allowedOrigins = (process.env.CORS_ORIGIN || '*').split(',').map(o => o.trim())

    if (!origin) return callback(null, true)

    if (allowedOrigins.includes('*') || allowedOrigins.includes(origin)) {
      return callback(null, true)
    }

    console.warn(`⚠️  [CORS] 非白名单 Origin: ${origin}，已放行但请检查 CORS_ORIGIN 配置`)
    return callback(null, true)
  },
  credentials: true,
  methods: ['GET', 'HEAD', 'PUT', 'PATCH', 'POST', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With', 'X-Internal-Key', 'x-user-id'],
  optionsSuccessStatus: 200
}))

// JSON 解析中间件 - 500MB 限制，与 backend 一致
app.use(express.json({ limit: '500mb' }))
app.use(express.urlencoded({ extended: true, limit: '500mb' }))

// 路由挂载
app.use('/health', require('./routes/health'))
app.use('/api/ai/furniai', require('./routes/furniai'))
app.use('/api/ai/sku-ai', require('./routes/skuAi'))
app.use('/api/ai/miniapp', require('./routes/miniappAi'))
app.use('/proxy', require('./routes/proxy'))

// 管理面板路由（静态页面 + 管理API）
app.use('/admin', require('./routes/admin'))

// 404 处理
app.use((req, res) => {
  res.status(404).json({
    code: 404,
    message: 'Not Found',
    data: null
  })
})

// 错误处理中间件
app.use((err, req, res, _next) => {
  console.error('[FurnIAI] Error:', err.message)
  res.status(err.status || 500).json({
    success: false,
    message: err.message || 'Internal Server Error',
    code: err.status || 500
  })
})

module.exports = app

/**
 * FurnIAI — API接口模型
 * 将已完成的任务提炼为可复用的 API 接口（内置提示词 + 参考图模板）
 * 外部用户通过 slug 调用接口，只需传入待处理图片即可
 */
const mongoose = require('mongoose')

const apiEndpointSchema = new mongoose.Schema({
    // 接口名称，如"沙发材质替换"
    name: { type: String, required: true, trim: true },
    // 接口标识符（URL路径），唯一索引，如 "sofa-material-change"
    slug: { type: String, required: true, unique: true, index: true, trim: true },
    // 接口描述
    description: { type: String, default: '' },
    // 启用/禁用
    status: { type: String, enum: ['active', 'disabled'], default: 'active' },

    // ========== 从任务提炼的核心数据 ==========
    // 内置提示词（可编辑）
    prompt: { type: String, default: '' },
    // 参考图片列表（base64/GridFS ID/URL）
    referenceImages: [mongoose.Schema.Types.Mixed],

    // ========== 调用配置 ==========
    // 指定通道ID（可选，空=auto）
    channelId: { type: String, default: 'auto' },
    // 指定模型（可选）
    model: { type: String, default: '' },

    // ========== 来源追溯 ==========
    // 来源任务ID（FurniaiTask 的 _id）
    sourceTaskId: { type: String, default: null },

    // ========== 统计 ==========
    stats: {
        totalCalls: { type: Number, default: 0 },
        successCalls: { type: Number, default: 0 },
        failedCalls: { type: Number, default: 0 },
        lastCallAt: { type: Date, default: null },
    },
}, {
    timestamps: true, // 自动 createdAt / updatedAt
})

/**
 * 根据名称自动生成 slug（中文转拼音太复杂，这里用时间戳+随机数）
 */
apiEndpointSchema.statics.generateSlug = function (name) {
    // 把名称中的特殊字符替换掉，保留英文字母和数字
    const base = name.replace(/[^a-zA-Z0-9]/g, '').toLowerCase()
    const suffix = Date.now().toString(36).slice(-4)
    return (base || 'api') + '-' + suffix
}

/**
 * 自动生成对接文档（根据接口配置动态拼装）
 * @param {string} baseUrl - 服务基础URL，如 https://hzh.sealos.run
 * @returns {object} 对接文档对象
 */
apiEndpointSchema.methods.generateDoc = function (baseUrl = '') {
    const endpoint = this
    const callUrl = `${baseUrl}/proxy/v1/endpoints/${endpoint.slug}`

    // 参数说明
    const params = [
        { name: 'images', type: 'array<string>', required: true, description: '待处理图片列表（base64 格式，如 "data:image/png;base64,..."）' },
    ]
    // 如果没有内置 prompt，允许外部传入
    if (!endpoint.prompt) {
        params.push({ name: 'prompt', type: 'string', required: true, description: '提示词（该接口未内置提示词，需外部传入）' })
    } else {
        params.push({ name: 'prompt', type: 'string', required: false, description: '自定义提示词（可选，传入后会覆盖内置提示词）' })
    }

    // curl 示例
    const curlExample = `curl -X POST "${callUrl}" \\
  -H "Authorization: Bearer pk-你的密钥" \\
  -H "Content-Type: application/json" \\
  -d '{
    "images": ["data:image/png;base64,iVBORw0KGgo..."]
  }'`

    // Python 示例
    const pythonExample = `import requests
import base64

# 读取图片并转为 base64
with open("input.jpg", "rb") as f:
    img_b64 = "data:image/jpeg;base64," + base64.b64encode(f.read()).decode()

resp = requests.post(
    "${callUrl}",
    headers={
        "Authorization": "Bearer pk-你的密钥",
        "Content-Type": "application/json"
    },
    json={"images": [img_b64]}
)
print(resp.json())`

    // Node.js 示例
    const nodeExample = `const fs = require('fs');

const imgBuffer = fs.readFileSync('input.jpg');
const imgB64 = 'data:image/jpeg;base64,' + imgBuffer.toString('base64');

const resp = await fetch("${callUrl}", {
    method: "POST",
    headers: {
        "Authorization": "Bearer pk-你的密钥",
        "Content-Type": "application/json"
    },
    body: JSON.stringify({ images: [imgB64] })
});
const result = await resp.json();
console.log(result);`

    // 响应格式说明
    const responseFormat = {
        success: true,
        data: {
            requestId: '任务ID',
            status: 'succeeded',
            results: [
                {
                    taskType: '任务类型',
                    status: 'completed',
                    resultBase64: 'data:image/png;base64,...（生成结果图片）',
                }
            ]
        }
    }

    return {
        name: endpoint.name,
        slug: endpoint.slug,
        description: endpoint.description || '暂无描述',
        status: endpoint.status,
        callUrl,
        method: 'POST',
        auth: {
            type: 'Bearer Token',
            header: 'Authorization: Bearer pk-你的密钥',
            description: '需要在管理面板「密钥管理」中创建平台密钥',
        },
        params,
        hasBuiltinPrompt: !!endpoint.prompt,
        builtinPromptPreview: endpoint.prompt ? (endpoint.prompt.length > 100 ? endpoint.prompt.slice(0, 100) + '...' : endpoint.prompt) : null,
        hasReferenceImages: endpoint.referenceImages && endpoint.referenceImages.length > 0,
        referenceImageCount: endpoint.referenceImages ? endpoint.referenceImages.length : 0,
        examples: {
            curl: curlExample,
            python: pythonExample,
            nodejs: nodeExample,
        },
        responseFormat,
        stats: endpoint.stats,
    }
}

module.exports = mongoose.model('ApiEndpoint', apiEndpointSchema)

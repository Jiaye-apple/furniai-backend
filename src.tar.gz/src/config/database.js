const mongoose = require('mongoose')

const connectDB = async () => {
  const uri = process.env.FURNIAI_MONGODB_URI
  if (!uri) {
    console.error('❌ FURNIAI_MONGODB_URI 未配置')
    process.exit(1)
  }

  try {
    const conn = await mongoose.connect(uri)
    console.log(`[FurnIAI] MongoDB connected: ${conn.connection.host}`)
    return conn
  } catch (err) {
    console.error(`[FurnIAI] MongoDB connection error: ${err.message}`)
    process.exit(1)
  }
}

module.exports = connectDB

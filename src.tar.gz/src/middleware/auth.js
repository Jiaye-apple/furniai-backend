const jwt = require('jsonwebtoken')
const { errorResponse } = require('../utils/response')
const PlatformKey = require('../models/PlatformKey')

/**
 * FurnIAI 认证中间件
 * 
 * 认证优先级：
 * 1. X-Internal-Key 头 → 内部服务间调用（跳过 JWT）
 * 2. Authorization: Bearer pk-xxx → 平台密钥认证
 * 3. Authorization: Bearer <token> → JWT 验证（独立统计，不关联任何平台密钥）
 */
const auth = async (req, res, next) => {
  try {
    // 1. 内部服务调用认证
    const internalKey = req.headers['x-internal-key']
    if (internalKey && internalKey === process.env.FURNIAI_INTERNAL_KEY) {
      req.userId = req.headers['x-user-id'] || 'internal'
      req.user = { _id: req.userId, role: 'internal' }
      return next()
    }

    // 提取 Bearer token
    const token = req.headers.authorization?.split(' ')[1]
    if (!token) {
      return res.status(401).json(errorResponse('No token provided', 401))
    }

    // 2. 平台密钥认证（pk- 前缀）
    if (token.startsWith('pk-')) {
      const platformKey = await PlatformKey.findOne({ key: token })
      if (!platformKey) {
        return res.status(401).json(errorResponse('Invalid platform key', 401))
      }
      if (platformKey.status !== 'active') {
        return res.status(401).json(errorResponse('Platform key is disabled', 401))
      }
      // 注入平台信息到请求对象
      req.userId = 'platform:' + platformKey.name
      req.user = { _id: req.userId, role: 'platform' }
      req.platformKey = platformKey  // 供 controller 更新统计
      return next()
    }

    // 3. JWT 验证 — 不关联任何平台密钥，JWT 调用独立统计
    const decoded = jwt.verify(token, process.env.JWT_SECRET)
    req.userId = decoded.userId
    req.user = { _id: decoded.userId }
    // req.platformKey 不设置 → controller 中 if(req.platformKey) 不触发 → JWT 不计入平台密钥统计
    next()
  } catch (err) {
    return res.status(401).json(errorResponse('Invalid token', 401))
  }
}

module.exports = { auth }

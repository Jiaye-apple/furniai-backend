/**
 * SkuAI — Task Processor
 * 从 skuAiController 中提取的任务处理逻辑，由 taskQueue 统一调度
 */
const SkuAiTask = require('../models/SkuAiTask')
const PlatformKey = require('../models/PlatformKey')
const jwtCounter = require('../utils/jwtCounter')
const geminiClient = require('./geminiClient')
const promptBuilder = require('./promptBuilder')
const imageProcessor = require('./imageProcessor')
const taskQueue = require('./taskQueue')

// taskType 前端 key → FurnIAI promptBuilder taskType 映射
const TASK_TYPE_MAP = {
  whiteBg: 'white-bg',
  effect: 'scene',
  dimension: 'dimensions',
  multiAngle: 'cad-views',
  crossSection: 'cross-section',
  sixViews: 'six-views',
  scaleDrawing: 'scale-drawing',
  video: null,
}

/**
 * 解析前端 taskType（支持 baseType:subType 格式）→ promptBuilder taskType
 * - whiteBg:{view} → multi-view:{view}（6 种视角）
 * - whiteBg:collage → multi-view:collage
 * - whiteBg:original-hd → white-bg（方案C走标准白底图流程）
 * - effect:{style} → scene（风格通过 options 传递）
 * - 不带子类型的基础类型映射到原有 TASK_TYPE_MAP
 * - 无法识别的基础类型返回 null
 */
function resolveTaskType(frontendKey) {
  const [base, sub] = frontendKey.split(':')
  const furniaiBase = TASK_TYPE_MAP[base]
  if (!furniaiBase) return null

  // 白底图子类型 → multi-view:subType 或特殊类型
  if (base === 'whiteBg' && sub) {
    if (sub === 'collage') return 'multi-view:collage'
    if (sub === 'original-hd') return 'white-bg'
    return `multi-view:${sub}`
  }
  // 效果图子类型 → scene（风格通过 options 传递）
  if (base === 'effect') {
    return 'scene'
  }
  return furniaiBase
}

const fileIdToBase64 = imageProcessor.fileIdToBase64
const saveBase64ToFile = (base64Data, prefix) => imageProcessor.saveBase64ToGridFS(base64Data, prefix)

/**
 * 异步处理单个 SkuAI 任务的所有子项
 * 由 taskQueue 调度调用
 */
async function processTask(taskId) {
  const task = await SkuAiTask.findById(taskId)
  if (!task || task.status === 'canceled') return

  // timeline 快捷写入
  const _tl = (phase, msg) => taskQueue.pushTimeline(taskId, 'skuai', phase, msg)
  const _fmtErr = (err) => taskQueue.formatError(err)

  try {
    const startedAt = new Date();
    const updatedAt = new Date();
    const updateData = {
      status: 'running',
      startedAt,
      updatedAt
    };

    // 预写入当前活跃通道和模型，使任务处理中阶段前端就能显示（API 返回后会覆盖为实际值）
    const configMgr = require('./configManager')
    const activeChannels = configMgr.get('channelPriority')?.filter(c => c.enabled) || []
    const primaryCh = activeChannels[0]
    if (primaryCh) {
      updateData['options.channel'] = primaryCh.id;
      updateData.modelUsed = primaryCh.imageModel || null;
      if (!task.options) task.options = {};
      task.options.channel = primaryCh.id;
      task.modelUsed = primaryCh.imageModel || null;
    }

    await SkuAiTask.updateOne({ _id: taskId }, { $set: updateData });
    task.status = 'running';
    task.startedAt = startedAt;
    task.updatedAt = updatedAt;

    _tl('task_start', `任务开始执行，通道=${primaryCh?.id || 'auto'}，模型=${primaryCh?.imageModel || '-'}，共 ${task.items.length} 个子项`)
    const taskStartTime = Date.now()

    // 加载关联的平台密钥（用于子任务完成后异步更新调用统计）
    let platformKey = null
    if (task.platformKeyId) {
      try {
        platformKey = await PlatformKey.findById(task.platformKeyId)
        _tl('platform_key', `平台密钥已加载: ${platformKey?.name || '-'}`)
      } catch (e) {
        _tl('platform_key', `平台密钥加载失败（不影响生图）: ${e.message}`)
        console.warn('[SkuAI] 加载平台密钥失败（不影响生图）:', e.message)
      }
    }

    // 读取第一张参考图的 base64（优先使用预处理缓存）
    let referenceBase64 = null
    if (task.referenceImages.length > 0) {
      _tl('ref_load_start', `开始加载参考图 ${String(task.referenceImages[0]).slice(0, 12)}...`)
      try {
        const refId = String(task.referenceImages[0])
        const cached = taskQueue.getPreprocessedImage(refId)
        if (cached) {
          referenceBase64 = imageProcessor.toDataUrl(cached)
          _tl('ref_load_done', `参考图加载完成（命中预处理缓存）`)
          console.log(`[SkuAI] Using preprocessed reference image: ${refId.slice(0, 12)}...`)
        } else {
          const refLoadStart = Date.now()
          referenceBase64 = await fileIdToBase64(task.referenceImages[0])
          _tl('ref_load_done', `参考图加载完成（从存储读取），耗时 ${Date.now() - refLoadStart}ms`)
        }
      } catch (err) {
        _tl('ref_load_fail', `参考图加载失败: ${_fmtErr(err)}`)
        console.error(`[SkuAI] 读取参考图失败: ${err.message}`)
        await SkuAiTask.updateOne({ _id: taskId }, {
          $set: {
            status: 'failed',
            error: '参考图读取失败: ' + (err.message || String(err)),
            completedAt: new Date(),
            updatedAt: new Date()
          }
        });
        return
      }
    }

    // 并行处理子项
    let completedCount = 0
    let failedCount = 0
    const totalItems = task.items.length

    for (const item of task.items) {
      if (item.status === 'completed' || item.status === 'skipped') {
        completedCount++
      }
    }

    const pendingItems = task.items.filter(
      item => item.status !== 'completed' && item.status !== 'skipped'
    )

    const processableItems = []
    for (const item of pendingItems) {
      if (item.taskType === 'video' || !resolveTaskType(item.taskType)) {
        item.status = 'skipped'
        item.error = '暂不支持此生成类型'
        item.completedAt = new Date()
        completedCount++
      } else {
        processableItems.push(item)
      }
    }

    if (processableItems.length > 0) {
      const itemPromises = processableItems.map(item => {
        const itemIndex = task.items.findIndex(i => i._id.toString() === item._id.toString())

        return (async () => {
          try {
            await SkuAiTask.findByIdAndUpdate(taskId, {
              $set: {
                [`items.${itemIndex}.status`]: 'processing',
                [`items.${itemIndex}.startedAt`]: new Date(),
                updatedAt: new Date(),
              }
            })

            const analysis = null

            const furniaiType = resolveTaskType(item.taskType)
            const genOptions = {
              userContext: task.options.userContext || '',
              enableHD: task.options.enableHD || false,
            }

            // 解析子类型
            const [baseType, subType] = item.taskType.split(':')

            // 效果图：将风格传入 options
            if (baseType === 'effect' && subType) {
              genOptions.sceneStyle = subType
            }

            // 白底图方案B：将视角信息传入 options
            if (baseType === 'whiteBg' && subType && subType !== 'collage' && subType !== 'original-hd') {
              genOptions.angleName = subType
            }

            // 白底图方案A：拼图模式
            if (baseType === 'whiteBg' && subType === 'collage') {
              genOptions.collageMode = true
            }

            if (item.taskType === 'dimension' && task.options.userContext) {
              genOptions.userContext = `尺寸标注图。${task.options.userContext}`
            }

            const prompt = promptBuilder.buildVisualPrompt(furniaiType, analysis || {}, genOptions)
            _tl('prompt_built', `子项 [${item.taskType}] Prompt 已构建，长度=${prompt.length} 字符`)

            // 保存 prompt 到数据库，方便管理面板查看输入
            await SkuAiTask.findByIdAndUpdate(taskId, {
              $set: { [`items.${itemIndex}.prompt`]: prompt }
            })

            console.log(`[SkuAI] 生成图片: taskId=${taskId}, type=${item.taskType}, furniaiType=${furniaiType}`)
            _tl('api_call', `子项 [${item.taskType}] 正在调用 AI 生图 API...`)
            const startTime = Date.now()

            const pureRef = imageProcessor.extractPureBase64(referenceBase64)
            const result = await geminiClient.generateImage(prompt, pureRef, {
              enableHD: genOptions.enableHD,
            })

            const elapsed = Date.now() - startTime
            const elapsedSec = (elapsed / 1000).toFixed(1)
            _tl('api_done', `子项 [${item.taskType}] API 响应返回，耗时 ${elapsed}ms，hasImage=${!!result.image}，通道=${result.channel || '-'}，模型=${result.model || '-'}`)
            console.log(`[SkuAI] ⏱️ 图片生成完成: type=${item.taskType}, 耗时=${elapsedSec}s (${elapsed}ms), hasImage=${!!result.image}, taskId=${taskId}`)

            if (result.image) {
              _tl('save_image', `子项 [${item.taskType}] 正在保存图片到存储...`)
              const dataUrl = imageProcessor.toDataUrl(result.image)
              const fileId = await saveBase64ToFile(dataUrl, `ai-${task.skuCode}-${item.taskType}`)
              _tl('save_done', `子项 [${item.taskType}] 图片已保存, fileId=${fileId}`)
              completedCount++

              const updateData = {
                [`items.${itemIndex}.resultFileId`]: fileId,
                [`items.${itemIndex}.status`]: 'completed',
                [`items.${itemIndex}.completedAt`]: new Date(),
                progress: Math.round(((completedCount + failedCount) / totalItems) * 100),
                updatedAt: new Date(),
              }
              if (result.channel) updateData['options.channel'] = result.channel
              if (result.model) updateData['modelUsed'] = result.model

              await SkuAiTask.findByIdAndUpdate(taskId, {
                $set: updateData
              })
              // 异步更新调用统计（成功），不阻塞生图流程
              if (platformKey) {
                platformKey.recordSuccess(promptBuilder.calculateCreditCost(furniaiType)).catch(e =>
                  console.error('[SkuAI] 平台统计更新失败:', e.message)
                )
              } else {
                jwtCounter.recordSuccess().catch(e => console.error('[SkuAI] JWT统计更新失败:', e.message))
              }
            } else {
              _tl('item_failed', `子项 [${item.taskType}] 失败: 生成结果无图片数据`)
              failedCount++
              await SkuAiTask.findByIdAndUpdate(taskId, {
                $set: {
                  [`items.${itemIndex}.status`]: 'failed',
                  [`items.${itemIndex}.error`]: '生成结果无图片数据',
                  [`items.${itemIndex}.completedAt`]: new Date(),
                  progress: Math.round(((completedCount + failedCount) / totalItems) * 100),
                  updatedAt: new Date(),
                }
              })
              // 异步更新调用统计（失败），不阻塞生图流程
              if (platformKey) {
                platformKey.recordFailure().catch(e =>
                  console.error('[SkuAI] 平台统计更新失败:', e.message)
                )
              } else {
                jwtCounter.recordFailure().catch(e => console.error('[SkuAI] JWT统计更新失败:', e.message))
              }
            }
          } catch (err) {
            const errMsg = err.message || String(err) || '未知生成错误'
            _tl('item_failed', `子项 [${item.taskType}] 异常: ${_fmtErr(err)}`)
            console.error(`[SkuAI] 生成失败: taskId=${taskId}, type=${item.taskType}, error=${errMsg}`)
            failedCount++
            await SkuAiTask.findByIdAndUpdate(taskId, {
              $set: {
                [`items.${itemIndex}.status`]: 'failed',
                [`items.${itemIndex}.error`]: errMsg,
                [`items.${itemIndex}.completedAt`]: new Date(),
                progress: Math.round(((completedCount + failedCount) / totalItems) * 100),
                updatedAt: new Date(),
              }
            })
            // 异步更新调用统计（异常失败），不阻塞生图流程
            if (platformKey) {
              platformKey.recordFailure().catch(e =>
                console.error('[SkuAI] 平台统计更新失败:', e.message)
              )
            } else {
              jwtCounter.recordFailure().catch(e => console.error('[SkuAI] JWT统计更新失败:', e.message))
            }
          }
        })()
      })

      await Promise.allSettled(itemPromises)
    } else {
      await SkuAiTask.updateOne({ _id: taskId }, {
        $set: {
          progress: Math.round(((completedCount + failedCount) / totalItems) * 100),
          updatedAt: new Date()
        }
      });
    }

    const finalStatus = failedCount === totalItems ? 'failed' : 'succeeded'
    const finalError = failedCount === totalItems ? '所有子任务均失败' : undefined
    const finalUpdate = {
      $set: {
        progress: 100,
        completedAt: new Date(),
        updatedAt: new Date(),
        status: finalStatus,
      }
    }
    if (finalError) finalUpdate.$set.error = finalError

    await SkuAiTask.findByIdAndUpdate(taskId, finalUpdate)
    const totalElapsed = ((Date.now() - taskStartTime) / 1000).toFixed(1)
    _tl('task_completed', `任务完成: status=${finalStatus}, 成功=${completedCount}, 失败=${failedCount}, 总耗时=${totalElapsed}s`)
    console.log(`[SkuAI] ✅ 任务完成: taskId=${taskId}, status=${finalStatus}, completed=${completedCount}, failed=${failedCount}, 总耗时=${totalElapsed}s`)
  } catch (err) {
    const errMsg = err.message || String(err) || '任务处理异常'
    _tl('task_failed', `任务异常: ${_fmtErr(err)}`)
    console.error(`[SkuAI] 任务处理异常: taskId=${taskId}, error=${errMsg}`)
    await SkuAiTask.findByIdAndUpdate(taskId, {
      $set: {
        status: 'failed',
        error: errMsg,
        completedAt: new Date(),
        updatedAt: new Date(),
      }
    })
  }
}

// Register with taskQueue
taskQueue.registerHandler('skuai', processTask)

module.exports = { processTask, resolveTaskType }

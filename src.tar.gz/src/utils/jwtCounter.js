/**
 * JWT 调用计数器 — 独立于平台密钥的实时调用统计
 * 
 * 使用 MongoDB 原子操作 $inc 确保并发安全
 * 存储在 jwtcallstats 集合的单个文档中
 */
const mongoose = require('mongoose')

const COLLECTION = 'jwtcallstats'
const DOC_ID = 'jwt_global'

// 获取 UTC+8 时区今日日期字符串 YYYY-MM-DD
function getTodayCST() {
    const now = new Date()
    const cst = new Date(now.getTime() + 8 * 60 * 60 * 1000)
    return cst.toISOString().slice(0, 10)
}

/**
 * 记录一次成功调用（原子操作）
 */
async function recordSuccess() {
    const today = getTodayCST()
    const col = mongoose.connection.db.collection(COLLECTION)
    // 先尝试日期匹配的原子更新
    const r = await col.updateOne(
        { _id: DOC_ID, todayDate: today },
        {
            $inc: { totalCalls: 1, successCalls: 1, todayCalls: 1 },
            $set: { lastCallAt: new Date() }
        }
    )
    if (r.matchedCount === 0) {
        // 日期变了或文档不存在 → 重置今日计数
        await col.updateOne(
            { _id: DOC_ID },
            {
                $inc: { totalCalls: 1, successCalls: 1 },
                $set: { todayCalls: 1, todayDate: today, lastCallAt: new Date() }
            },
            { upsert: true }
        )
    }
}

/**
 * 记录一次失败调用（原子操作）
 */
async function recordFailure() {
    const today = getTodayCST()
    const col = mongoose.connection.db.collection(COLLECTION)
    const r = await col.updateOne(
        { _id: DOC_ID, todayDate: today },
        {
            $inc: { totalCalls: 1, failedCalls: 1, todayCalls: 1 },
            $set: { lastCallAt: new Date() }
        }
    )
    if (r.matchedCount === 0) {
        await col.updateOne(
            { _id: DOC_ID },
            {
                $inc: { totalCalls: 1, failedCalls: 1 },
                $set: { todayCalls: 1, todayDate: today, lastCallAt: new Date() }
            },
            { upsert: true }
        )
    }
}

/**
 * 读取 JWT 调用统计
 */
async function getStats() {
    const col = mongoose.connection.db.collection(COLLECTION)
    const doc = await col.findOne({ _id: DOC_ID })
    if (!doc) return { totalCalls: 0, todayCalls: 0, successCalls: 0, failedCalls: 0 }
    const today = getTodayCST()
    return {
        totalCalls: doc.totalCalls || 0,
        // 日期不匹配时今日计数归零
        todayCalls: doc.todayDate === today ? (doc.todayCalls || 0) : 0,
        successCalls: doc.successCalls || 0,
        failedCalls: doc.failedCalls || 0,
        lastCallAt: doc.lastCallAt || null,
    }
}

module.exports = { recordSuccess, recordFailure, getStats }
